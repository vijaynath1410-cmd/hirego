# HireGo Candidate Portal

A responsive React and Vite candidate portal with linked sign-in, account creation, and a candidate profile dashboard.

## Start the app

1. Install Node.js (version supported by the Vite version in `package.json`).
2. Run `npm install`.
3. Run `npm run dev` and open the local URL shown in the terminal.

## How the demo works

Multiple candidates can each create an account in the same browser. Profiles are saved separately by email, so signing up with another email does not replace an existing candidate. Sign in with the matching email and password, and use Sign out to return to the login page. The profile includes education, experience, skills, links, a profile image, and a resume filename. Profile photos are resized before local storage.

This ZIP is a front-end prototype. To use real accounts across devices, connect the forms to an authentication and profile API.
