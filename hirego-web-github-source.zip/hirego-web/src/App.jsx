import { useEffect, useState } from "react";
import "./App.css";

const STORAGE_KEY = "hirego.candidate.accounts.v1";
const LEGACY_STORAGE_KEY = "hirego.candidate.account.v1";
const SESSION_KEY = "hirego.candidate.session.v1";
const EMPTY_PROFILE = {
  fullName: "",
  email: "",
  phone: "",
  degree: "",
  college: "",
  cgpa: "",
  experience: "",
  skills: [],
  github: "",
  linkedin: "",
  profilePhoto: "",
  resumeName: "",
};

function readAccounts() {
  try {
    const value = localStorage.getItem(STORAGE_KEY);
    if (value) return JSON.parse(value);

    // Migrate the earlier single-candidate demo account without losing its profile.
    const legacyValue = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!legacyValue) return {};
    const legacyAccount = JSON.parse(legacyValue);
    const email = legacyAccount?.candidate?.email?.trim()?.toLowerCase();
    if (!email) return {};
    const accounts = { [email]: legacyAccount };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts));
    return accounts;
  } catch {
    return {};
  }
}

function readAccount(email) {
  return readAccounts()[email?.trim()?.toLowerCase()] || null;
}

function saveAccount(account, previousEmail = "") {
  const accounts = readAccounts();
  const normalizedEmail = account.candidate.email.trim().toLowerCase();
  const oldEmail = previousEmail.trim().toLowerCase();
  if (oldEmail && oldEmail !== normalizedEmail) delete accounts[oldEmail];
  accounts[normalizedEmail] = account;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(accounts));
}

function readSessionAccount() {
  return readAccount(localStorage.getItem(SESSION_KEY));
}

function startSession(email) {
  localStorage.setItem(SESSION_KEY, email.trim().toLowerCase());
}

async function hashPassword(password) {
  const bytes = new TextEncoder().encode(password);
  const digest = await window.crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function fileAsDataUrl(file) {
  try {
    const image = await createImageBitmap(file);
    const scale = Math.min(1, 512 / Math.max(image.width, image.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.width * scale));
    canvas.height = Math.max(1, Math.round(image.height * scale));
    canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
    image.close();
    return canvas.toDataURL("image/jpeg", 0.82);
  } catch {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error("We could not read that image. Try another file."));
      reader.readAsDataURL(file);
    });
  }
}

function Brand({ compact = false }) {
  return (
    <a className={`brand-lockup${compact ? " brand-lockup-compact" : ""}`} href="#/login" aria-label="HireGo home">
      <span className="brand-symbol" aria-hidden="true">
        <svg viewBox="0 0 40 36" fill="none">
          <circle cx="20" cy="8" r="5" fill="currentColor" />
          <circle cx="8.5" cy="13" r="4" fill="#079A8D" />
          <circle cx="31.5" cy="13" r="4" fill="#079A8D" />
          <path d="M11 31v-7a9 9 0 0 1 18 0v7H11Z" fill="currentColor" />
          <path d="M1 30v-3a7.5 7.5 0 0 1 11-6.6A12 12 0 0 0 8 30H1Zm38 0h-7a12 12 0 0 0-4-9.6A7.5 7.5 0 0 1 39 27v3Z" fill="#079A8D" />
        </svg>
      </span>
      <span className="brand-name"><span>Hire</span><span className="brand-blue">G</span><span className="brand-teal">o</span></span>
    </a>
  );
}

function Field({ label, hint, children }) {
  return (
    <label className="form-field">
      <span className="field-label">{label}</span>
      {children}
      {hint && <span className="field-hint">{hint}</span>}
    </label>
  );
}

function LoginPage({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const account = readAccount(email);
      if (!account) {
        setError("We couldn't find an account with that email. Create an account to get started.");
        return;
      }
      if (await hashPassword(password) !== account.passwordHash) {
        setError("That password doesn't match this account. Please try again.");
        return;
      }
      startSession(account.candidate.email);
      onLogin(account);
    } catch {
      setError("Sign in is unavailable in this browser. Please try again using the project preview.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthLayout>
      <section className="auth-card login-card" aria-labelledby="login-title">
        <div className="auth-brand"><Brand /><p>Better Skills <span>·</span> Better Careers</p></div>
        <h1 id="login-title">Welcome back</h1>
        <p className="auth-intro">Sign in to view your HireGo candidate profile.</p>
        <form onSubmit={submit} className="form-stack">
          <Field label="Email address">
            <input className="text-input" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={(event) => setEmail(event.target.value)} required />
          </Field>
          <Field label="Password">
            <span className="password-wrap">
              <input className="text-input" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Enter your password" value={password} onChange={(event) => setPassword(event.target.value)} required />
              <button className="password-toggle" type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? "Hide" : "Show"}</button>
            </span>
          </Field>
          {error && <p className="form-alert" role="alert">{error}</p>}
          <button className="primary-button" type="submit" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
        </form>
        <p className="auth-switch">New to HireGo? <a href="#/signup">Create an account</a></p>
      </section>
    </AuthLayout>
  );
}

function AuthLayout({ children }) {
  return (
    <main className="app-shell auth-shell">
      <div className="auth-wrap">{children}</div>
      <p className="page-footnote">Find your next opportunity with HireGo</p>
    </main>
  );
}

function SignupPage({ existingAccount, editing, onSave }) {
  const prior = existingAccount?.candidate || EMPTY_PROFILE;
  const [profile, setProfile] = useState(() => ({ ...EMPTY_PROFILE, ...prior, skills: Array.isArray(prior.skills) ? prior.skills.join(", ") : (prior.skills || "") }));
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  function update(name, value) {
    setProfile((current) => ({ ...current, [name]: value }));
  }

  async function choosePhoto(event) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Choose an image file for your profile photo.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Choose a profile photo smaller than 5 MB.");
      return;
    }
    try {
      setError("");
      update("profilePhoto", await fileAsDataUrl(file));
    } catch (uploadError) {
      setError(uploadError.message);
    }
  }

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (!editing && password.length < 8) {
      setError("Use a password with at least 8 characters.");
      return;
    }
    if (!editing && password !== confirmPassword) {
      setError("Your passwords don't match.");
      return;
    }
    const normalizedEmail = profile.email.trim().toLowerCase();
    const matchingAccount = readAccount(normalizedEmail);
    const originalEmail = existingAccount?.candidate?.email || "";
    if (matchingAccount && normalizedEmail !== originalEmail.trim().toLowerCase()) {
      setError("An account with this email already exists. Sign in or use a different email.");
      return;
    }
    setBusy(true);
    try {
      const passwordHash = editing ? existingAccount.passwordHash : await hashPassword(password);
      const account = {
        candidate: { ...profile, email: profile.email.trim().toLowerCase() },
        passwordHash,
        createdAt: existingAccount?.createdAt || new Date().toISOString(),
      };
      saveAccount(account, editing ? originalEmail : "");
      startSession(account.candidate.email);
      onSave(account);
    } catch {
      setError("We couldn't save your profile. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthLayout>
      <section className="auth-card signup-card" aria-labelledby="signup-title">
        <div className="auth-brand"><Brand /><p>Better Skills <span>·</span> Better Careers</p></div>
        <h1 id="signup-title">{editing ? "Edit your profile" : "Create your account"}</h1>
        <p className="auth-intro">{editing ? "Keep your candidate profile up to date." : "Build your profile and take the next step in your career."}</p>
        <form onSubmit={submit} className="form-stack">
          <div className="photo-field">
            <div className="photo-preview">
              {profile.profilePhoto ? <img src={profile.profilePhoto} alt="Candidate profile" /> : <span aria-hidden="true">{profile.fullName?.trim()?.charAt(0)?.toUpperCase() || "＋"}</span>}
            </div>
            <div className="photo-copy"><strong>Profile photo</strong><span>Optional · JPG, PNG, or WEBP up to 5 MB</span></div>
            <label className="secondary-button photo-button">{profile.profilePhoto ? "Change photo" : "Upload photo"}<input type="file" accept="image/*" onChange={choosePhoto} /></label>
          </div>

          <div className="form-grid">
            <Field label="Full name"><input className="text-input" autoComplete="name" placeholder="Priya Sharma" value={profile.fullName} onChange={(event) => update("fullName", event.target.value)} required /></Field>
            <Field label="Email address"><input className="text-input" type="email" autoComplete="email" placeholder="you@example.com" value={profile.email} onChange={(event) => update("email", event.target.value)} required /></Field>
            <Field label="Phone number"><input className="text-input" type="tel" autoComplete="tel" placeholder="+91 98765 43210" value={profile.phone} onChange={(event) => update("phone", event.target.value)} required /></Field>
            <Field label="Degree"><select className="text-input" value={profile.degree} onChange={(event) => update("degree", event.target.value)} required><option value="">Select your degree</option><option>Bachelor's</option><option>Master's</option><option>Diploma</option><option>Doctorate</option><option>Other</option></select></Field>
            <Field label="College or university"><input className="text-input" autoComplete="organization" placeholder="Institution name" value={profile.college} onChange={(event) => update("college", event.target.value)} required /></Field>
            <Field label="CGPA (out of 10)"><input className="text-input" type="number" min="0" max="10" step="0.01" placeholder="8.2" value={profile.cgpa} onChange={(event) => update("cgpa", event.target.value)} required /></Field>
            <Field label="Work experience"><select className="text-input" value={profile.experience} onChange={(event) => update("experience", event.target.value)} required><option value="">Select experience</option><option>Fresher</option><option>Less than 1 year</option><option>1–3 years</option><option>3–5 years</option><option>5+ years</option></select></Field>
            <Field label="Skills" hint="Separate skills with commas."><input className="text-input" placeholder="React, Communication, SQL" value={profile.skills} onChange={(event) => update("skills", event.target.value)} required /></Field>
            <Field label="Upload CV" hint="PDF, up to 5 MB."><input className="text-input file-input" type="file" accept="application/pdf,.pdf" onChange={(event) => update("resumeName", event.target.files?.[0]?.name || profile.resumeName)} /><span className="field-hint">{profile.resumeName ? `Selected: ${profile.resumeName}` : "Optional · PDF format"}</span></Field>
            <Field label="GitHub profile"><input className="text-input" type="url" placeholder="https://github.com/username" value={profile.github} onChange={(event) => update("github", event.target.value)} /></Field>
            <Field label="LinkedIn profile"><input className="text-input" type="url" placeholder="https://linkedin.com/in/username" value={profile.linkedin} onChange={(event) => update("linkedin", event.target.value)} /></Field>
            {!editing && <Field label="Password" hint="At least 8 characters."><span className="password-wrap"><input className="text-input" type={showPassword ? "text" : "password"} autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={8} /><button className="password-toggle" type="button" onClick={() => setShowPassword((value) => !value)}>{showPassword ? "Hide" : "Show"}</button></span></Field>}
            {!editing && <Field label="Confirm password"><input className="text-input" type="password" autoComplete="new-password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} required minLength={8} /></Field>}
          </div>
          {error && <p className="form-alert" role="alert">{error}</p>}
          <button className="primary-button" type="submit" disabled={busy}>{busy ? "Saving…" : editing ? "Save profile" : "Create account"}</button>
        </form>
        <p className="auth-switch">Already have an account? <a href="#/login">Sign in</a></p>
      </section>
    </AuthLayout>
  );
}

function ProfileAvatar({ candidate, large = false }) {
  const initials = candidate.fullName?.trim()?.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "HG";
  return <div className={`profile-avatar${large ? " profile-avatar-large" : ""}`}>{candidate.profilePhoto ? <img src={candidate.profilePhoto} alt={`${candidate.fullName} profile`} /> : <span>{initials}</span>}</div>;
}

function Dashboard({ account, onEdit, onLogout }) {
  const candidate = account.candidate;
  const skills = Array.isArray(candidate.skills) ? candidate.skills : String(candidate.skills || "").split(",").map((skill) => skill.trim()).filter(Boolean);
  const completionItems = [candidate.fullName, candidate.email, candidate.phone, candidate.degree, candidate.college, candidate.cgpa, candidate.experience, skills.length ? "skills" : ""];
  const completion = Math.round((completionItems.filter(Boolean).length / completionItems.length) * 100);

  return (
    <main className="app-shell dashboard-shell">
      <header className="dashboard-nav">
        <Brand compact />
        <div className="nav-actions"><span className="nav-greeting">Hi, {candidate.fullName?.split(" ")[0] || "there"}</span><button className="secondary-button" onClick={onLogout}>Sign out</button></div>
      </header>
      <div className="dashboard-content">
        <div className="dashboard-title-row"><div><p className="eyebrow">CANDIDATE SPACE</p><h1>Your profile</h1><p className="dashboard-subtitle">Review your information and keep it ready for your next opportunity.</p></div><button className="primary-button edit-button" onClick={onEdit}>Edit profile</button></div>
        <section className="completion-card" aria-label={`Profile ${completion}% complete`}>
          <div className="completion-top"><div><strong>Profile completion</strong><p>A complete profile helps employers get to know you.</p></div><span className="completion-number">{completion}%</span></div>
          <div className="progress-track"><span style={{ width: `${completion}%` }} /></div>
        </section>
        <div className="dashboard-grid">
          <aside className="summary-card">
            <ProfileAvatar candidate={candidate} large />
            <h2>{candidate.fullName || "Your name"}</h2>
            <p className="summary-degree">{candidate.degree || "Candidate"}{candidate.experience ? ` · ${candidate.experience}` : ""}</p>
            <p className="summary-college">{candidate.college || "Add your college or university"}</p>
            <div className="summary-contact"><span>{candidate.email}</span>{candidate.phone && <span>{candidate.phone}</span>}</div>
            <button className="secondary-button full-button" onClick={onEdit}>Update details</button>
          </aside>
          <div className="profile-sections">
            <section className="detail-card"><div className="section-heading"><h2>Personal information</h2><button onClick={onEdit} className="text-button">Edit</button></div><div className="detail-grid"><Detail label="Full name" value={candidate.fullName} /><Detail label="Email" value={candidate.email} /><Detail label="Phone" value={candidate.phone} /></div></section>
            <section className="detail-card"><div className="section-heading"><h2>Education</h2><button onClick={onEdit} className="text-button">Edit</button></div><div className="detail-grid"><Detail label="Degree" value={candidate.degree} /><Detail label="College or university" value={candidate.college} /><Detail label="CGPA" value={candidate.cgpa ? `${candidate.cgpa} / 10` : ""} /></div></section>
            <section className="detail-card"><div className="section-heading"><h2>Career profile</h2><button onClick={onEdit} className="text-button">Edit</button></div><div className="detail-grid"><Detail label="Work experience" value={candidate.experience} /><Detail label="Resume" value={candidate.resumeName} /></div><div className="skills-block"><span className="detail-label">Skills</span>{skills.length ? <div className="skill-list">{skills.map((skill) => <span className="skill-chip" key={skill}>{skill}</span>)}</div> : <p className="empty-value">Add your skills to complete your profile.</p>}</div></section>
            <section className="detail-card"><div className="section-heading"><h2>Professional links</h2><button onClick={onEdit} className="text-button">Edit</button></div><div className="detail-grid"><Detail label="GitHub" value={candidate.github} link /><Detail label="LinkedIn" value={candidate.linkedin} link /></div></section>
          </div>
        </div>
      </div>
    </main>
  );
}

function Detail({ label, value, link = false }) {
  return <div className="detail-item"><span className="detail-label">{label}</span>{value ? link ? <a className="detail-value detail-link" href={value} target="_blank" rel="noreferrer">{value}</a> : <span className="detail-value">{value}</span> : <span className="empty-value">Not added</span>}</div>;
}

function App() {
  const [route, setRoute] = useState(() => window.location.hash.replace(/^#\/?/, "") || "login");
  const [account, setAccount] = useState(readSessionAccount);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    const syncRoute = () => setRoute(window.location.hash.replace(/^#\/?/, "") || "login");
    window.addEventListener("hashchange", syncRoute);
    if (!window.location.hash) window.location.hash = "/login";
    return () => window.removeEventListener("hashchange", syncRoute);
  }, []);

  function go(screen) {
    window.location.hash = `/${screen}`;
  }

  function handleSave(nextAccount) {
    setAccount(nextAccount);
    setEditing(false);
    go("dashboard");
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
    setAccount(null);
    setEditing(false);
    go("login");
  }

  if (route === "dashboard" && account) return <Dashboard account={account} onEdit={() => { setEditing(true); go("signup"); }} onLogout={logout} />;
  if (route === "signup") return <SignupPage key={editing ? "edit" : "new"} existingAccount={account} editing={editing} onSave={handleSave} />;
  return <LoginPage onLogin={(savedAccount) => { setAccount(savedAccount); go("dashboard"); }} />;
}

export default App;


